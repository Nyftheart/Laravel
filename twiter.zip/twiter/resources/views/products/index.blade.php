@extends('products.layout')

@section('content')


    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
              <br>
              <br>
              <br>
              <br>
                <h2>APP suivi de projet</h2>
            </div>
            <div class="pull-right">
              <br>
              <br>
              <br>
              <br>
                <a class="btn btn-success" href="{{ route('products.create') }}">nouveau projet</a>
            </div>
        </div>
    </div>

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <table class="table table-bordered">
        <tr>
            <th>N°</th>
            <th>Créateur</th>
            <th>Details</th>
            <th width="280px">Action</th>
        </tr>
        @foreach ($products as $product)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $product->name }}</td>
            <td>{{ $product->detail }}</td>
            <td>
                <form action="{{ route('products.destroy',$product->id) }}" method="POST">

                    <a class="btn btn-info" href="{{ route('products.show',$product->id) }}">Affiche</a>

                    <a class="btn btn-primary" href="{{ route('products.edit',$product->id) }}">Modif</a>

                    @csrf
                    @method('DELETE')

                    <button type="submit" class="btn btn-danger">Sup</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>

    <a class="btn btn-info" href="/">Retour</a>



@endsection
<style>
.table-bordered {
    table-layout: fixed;
    width: 100%;
}

.table-bordered tr {
    border: 1px solid black;
    background:lightgrey;
}

body {
    background-image: url("https://codetheweb.blog/assets/img/posts/css-advanced-background-images/cover.jpg ");
    background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
