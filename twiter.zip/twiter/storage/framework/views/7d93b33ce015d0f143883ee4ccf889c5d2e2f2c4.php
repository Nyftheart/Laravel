

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
              <br>
              <br>
                <h2>Le projet</h2>
            </div>
            <div class="pull-right">
              <br>
              <br>
                <a class="btn btn-primary" href="<?php echo e(route('products.index')); ?>">retour</a>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nom projet:</strong>
                <?php echo e($product->name); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Details:</strong>
                <?php echo e($product->detail); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<style media="screen">
body {
    background-image: url("https://codetheweb.blog/assets/img/posts/css-advanced-background-images/cover.jpg ");
    background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

</style>

<?php echo $__env->make('products.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alexa\Desktop\Sync\Laravel\twiter\resources\views/products/show.blade.php ENDPATH**/ ?>